import readline from 'readline-sync';
import {DirectSecp256k1HdWallet} from "@cosmjs/proto-signing";
import {seiFunctionBot} from "./seibot.js";
import {readFileSync} from "fs";
import fs from "fs";


const content = readFileSync("mnemonics.txt", 'utf-8');
const mnemonics = content.split(/\r?\n/);


const writeOutMnemonics = () => {
    mnemonics.forEach(element => console.log(element));
}

// Hàm lấy địa chỉ ví bằng mnemonic
const getAddressFromMnemonic = async (mnemonic) => {
    const wallet = await DirectSecp256k1HdWallet.fromMnemonic(mnemonic, { prefix: 'sei' });
    const [firstWallet] = await wallet.getAccounts();
    return firstWallet.address;
};

// Hàm hiển thị tất cả địa chỉ ví ra console
const writeOutAddresses = async () => {
    const addresses = await Promise.all(mnemonics.map(mnemonic => getAddressFromMnemonic(mnemonic)));
    console.log('All Addresses:');
    addresses.forEach(address => console.log(address));

    const fileId = fs.openSync("allAddresses.txt", "w");
    fs.truncateSync("allAddresses.txt");
    addresses.forEach((address) => {
            fs.writeSync(fileId, address + "\r\n", null, "utf8");
            console.log(address);
    });
    fs.closeSync(fileId);
};

const checkBalances = async () => {
    const addresses = await Promise.all(mnemonics.map(mnemonic => getAddressFromMnemonic(mnemonic)));

    for (const address of addresses) {
        try {
            const walletBalance = await queryClient.cosmos.bank.v1beta1.allBalances({ address: address });

            const walletSeiBalance = walletBalance.balances.find(token => token.denom === 'usei');

            console.log(address, ' ', walletSeiBalance.amount);
        } catch (err) {
            console.log('Error in checking balance ');
        }
    }
};

const writeOutAddressesToSend = async () => {
    const addresses = await Promise.all(mnemonics.map(mnemonic => getAddressFromMnemonic(mnemonic)));
    console.log('All Addresses:');
    const fileId = fs.openSync("addressesToSend.txt", "w");
    fs.truncateSync("addressesToSend.txt");
    addresses.forEach((address,index) => {
        if (index % 2 === 0) {
            fs.writeSync(fileId, address + "\r\n", null, "utf8");
            console.log(address);
        }
    });
    fs.closeSync(fileId);
};

const generateMnemonics = async () => {
    const numMnemonics = readline.questionInt('Enter the number of mnemonics to generate: ');

    const newMnemonics = [];
    for (let i = 0; i < numMnemonics; i++) {
        const mnemonic = await DirectSecp256k1HdWallet.generate(12, {prefix: 'sei'});
        console.log(mnemonic.secret.data);
        newMnemonics.push(mnemonic.mnemonic);
    }

    fs.appendFileSync('mnemonics.txt', '\n' + newMnemonics.join('\n'));
    console.log(`Added ${numMnemonics} new mnemonics to mnemonics.txt`);

    return newMnemonics;
}

while (true) {
    console.log('1. Hien thi mnemonics');
    console.log('2. Hien thi address tu mnemonics');
    console.log('3. Hien thi address de send - dang test');
    console.log('4. Chay bot');
	console.log('5. Tao vi');
	console.log('6. Check Balances');
    console.log('7. Exit');

    const choice = readline.question('Choose menu number: ');

    switch (parseInt(choice)) {
        case 1:
            writeOutMnemonics();
            break;

        case 2:
            await writeOutAddresses();
            break;

        case 3:
            await writeOutAddressesToSend();
            break;

        case 4:
            // Thực hiện khởi chạy bot
            await seiFunctionBot(mnemonics);
            break;
			
        case 5:
            // Tao vi
            await generateMnemonics();
            break;

        case 6:
            await checkBalances();
            break;			
			
        case 7:
            console.log('Exiting...');
            process.exit(0)
            break;

        default:
            console.log('Invalid choice.');
            break;
    }

}


